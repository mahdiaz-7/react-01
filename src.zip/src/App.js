import React from 'react';
import Body from "./body/body" ;
import Header from './header/header';
import Foter from './foter/foter';
const App = () => {
  return (
    <div >
      <Header/>
     <Body/> 
     <Foter/>
    </div>
  );
};

export default App;

// class Multiplication extends Component {
//   constructor(props) {
//     super(props);
//     this.state = {
//       number1: '',
//       number2: '',
//       result: ''
//     };
//   }

//   handleInputChange = (event) => {
//     const { name, value } = event.target;
//     this.setState({ [name]: value });
//   }

//   calculateMultiplication = () => {
//     const { number1, number2 } = this.state;
//     const result = number1 * number2;
//     this.setState({ result });
//   }

//   render() {
//     const { number1, number2, result } = this.state;

//     return (
//       <div>
//         <form>
//           <input
//             type="number"
//             name="number1"
//             value={number1}
//             onChange={this.handleInputChange}
//           />
//           <input
//             type="number"
//             name="number2"
//             value={number2}
//             onChange={this.handleInputChange}
//           />
//           <button type="button" onClick={this.calculateMultiplication}>
//             Calculate
//           </button>
//         </form>
//         <p>Result: {result}</p>
//       </div>
//     );
//   }
// }

// export default Multiplication;

// **--*---*-*---*-*-*

// import React, { useState } from 'react';

// function MultiplyBoxes() {
//   const [box1, setBox1] = useState(0);
//   const [box2, setBox2] = useState(0);
//   const [result, setResult] = useState(0);

//   const multiplyNumbers = () => {
//     const multipliedValue = box1 * box2;
//     setResult(multipliedValue);
//   }

//   return (
//     <div>
//       <input
//         type="number"
//         value={box1}
//         onChange={(e) => setBox1(parseInt(e.target.value))}
//       />
//       <input
//         type="number"
//         value={box2}
//         onChange={(e) => setBox2(parseInt(e.target.value))}
//       />
//       <button onClick={multiplyNumbers}>ضرب</button>
//       <p>نتیجه: {result}</p>
//     </div>
//   );
// }

// export default MultiplyBoxes;
