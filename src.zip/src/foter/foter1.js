import React from 'react';
import Image1 from "./ecunion-8b792f56.png"
import Image2 from "./samandehi-6e2b448a.png"
import Image3 from "./1-min-6-250x230.png"
import Image4 from "./passenger-rights-48368f81.svg"
import Image5 from "./price.png"
import Image6 from "./state-airline-f45c55b2.svg"

const Foter1 = () => {
    return (
        <div className='border-t-2 border-b-2 border-solid border-grey-300 p-8 ml-96 mr-96'>
            <div className='flex gap-12'>
                
            <div className='grid-cols-2 gap-4 text-right'>
                    <img src="https://cdn.alibaba.ir/h2/desktop/assets/images/shawl_logotype-d6b14ca0.svg" className='w-36	 h-7'/>

                    <div className='pb-4 '>
                        <p className='text-left pb-4 pt-4'>تلفن پشتیبانی: ۰۲۱ - ۴۳۹۰۰۰۰۰</p>
                        <span className='text-left'>دفتر پشتیبانی: اکباتان، نبش اتوبان لشگری، کوی بیمه، خیابان بیمه چهارم،
                             بن‌بست گل‌ها، پلاک 1</span>
                    </div>
                    <div className='flex pt-6'>
                            <ul className='list-n flex'>
                                <div className='p-2 pl-0'>

                                <li className='w-20 h-20 border solid rounded p-2'>
                                    <img src={Image1}/>
                                </li>
                                </div>
                                <div className='p-2'>

                                <li className='w-20 border solid rounded p-2'>
                                    <img src={Image2}/>
                                </li>
                                </div>
                                <div className='p-2'>

                                <li className='w-20 h-20 border solid rounded p-2'>
                                    <img src={Image3} className='h24'/>
                                </li>
                                </div>
                                <div className='p-2'>

                                <li className='w-20 h-20 border solid rounded p-2'>
                                    <img src={Image4}/>
                                </li>
                                </div>
                                <div className='p-2'>

                                <li className='w-20  h-20 border solid rounded p-2'>
                                    <img src={Image5}/>
                                </li>
                                </div>
                                <div className='p-2'>

                                <li className='w-20 h-20 border solid rounded p-2'>
                                    <img src={Image6}/>
                                </li>
                                </div>
                            </ul>
                    </div>
                </div>
                
            <div className='grid-cols-2 gap-4 text-right	'>
                    <h4 className='text-l mb-4'>اطلاعات تکمیلی</h4>
                    <ul className='text-gray-400'>
                        <li>
                            <a>باشگاه همسفران</a>
                        </li>
                        <li>
                            <a>فروش سازمانی</a>
                        </li>
                        <li>
                            <a>همکاری با آژانس‌ها</a>
                        </li>
                        <li>
                            <a>فرصت‌های شغلی</a>
                        </li>
                    </ul>
                </div>              
                <div className='grid-cols-2 gap-4 text-right	'>
                    <h4 className='text-l mb-4'>خدمات مشتریان</h4>
                    <ul className='text-gray-400'>
                        <li>
                            <a>مرکز پشتیبانی آنلاین</a>
                        </li>
                        <li>
                            <a>راهنمای خرید</a>
                        </li>
                        <li>
                            <a>راهنمای استرداد</a>
                        </li>
                        <li>
                            <a>قوانین و مقررات</a>
                        </li>
                        <li>
                            <a>پرسش و پاسخ</a>
                        </li>
                    </ul>
                </div>
                <div className='grid-cols-2 gap-4 text-right	'>
                    <h4 className='text-l mb-4'>علی بابا</h4>
                    <ul className='text-gray-400'>
                        <li>
                            <a>درباره ما</a>
                        </li>
                        <li>
                            <a>تماس با ما</a>
                        </li>
                        <li>
                            <a>چرا علی‌بابا</a>
                        </li>
                        <li>
                            <a>علی بابا پلاس</a>
                        </li>
                        <li>
                            <a>بیمه مسافرتی</a>
                        </li>
                        <li>
                            <a>مجله علی‌بابا</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    );
};

export default Foter1;