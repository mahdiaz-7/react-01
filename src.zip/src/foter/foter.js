import React from 'react';
import Star from "./download.webp"
import Star1 from "./download (1).webp";
import Star2 from "./download (2).webp"
import Foter1 from "./foter1";
import Foter2 from "./foter2"
const Foter = () => {
    return (
        <div className='mt-24 h-24 w-full  border-t-2 border-solid border-grey-300'>
            <div className=' w-3/5	 flex items-center  ml-96'>
              <div className='flex p-10 '>
                    
                <div className='grid-cols-4	'>
                    <div className='flex'>

                    <div className='text-right'>
                            <h3 className='text-gray-800'>همسفر همه لحظات سفر</h3>
                            <span className='text-gray-600'>پشتیبانی و همراهی ۲۴ ساعته در تمامی مراحل سفر</span>
                        </div>
                        <div>
                            <img src={Star2} className='w-26	'/>
                        </div>
                    </div>
                       
                    </div>
                    <div className='grid-cols-4	'>
                        <div className='flex'>
                            
                    <div className='text-right '>
                            <h3 className='text-gray-800'>همسفر هر سفر</h3>
                            <span className='text-gray-600' >ارائه تمامی خدمات سفر (پرواز، قطار، اتوبوس، هتل و تور)</span>
                        </div>
                        <div>
                            <img src={Star1} className='w-26	'/>
                        </div>
                        </div>
                       
                    </div>
                    <div className='grid-cols-4	'>
                        <div className='flex'>

                        <div className='text-right '>
                            <h3 className='text-gray-800'>رتبه یک سفر</h3>
                            <span className='text-gray-600'>معتبرترین عرضه‌کننده محصولات   گردشگری در ایران</span>
                        </div>
                        <div>
                            <img src={Star} />
                        </div>
                       
                    </div> 
                        </div> 
                        
        
                </div>
                
            </div>
            <Foter1/>
            <Foter2/>
        </div>
    );
};

export default Foter;