import React, { useState, useEffect } from "react";

function Body() {
  const [num1, setNum1] = useState("");
  const [num2, setNum2] = useState("");
  const [result, setResult] = useState("");
  const [backgroundColor, setBackgroundColor] = useState("");

  useEffect(() => {
    if (result > 10 ) {
      setBackgroundColor("green");
    } else if (result < 10) {
      setBackgroundColor("blue");
    } else if (result === 10){
      setBackgroundColor("red");
    }if (result === NaN){
      setBackgroundColor("#fde68a")
    }
  }, [result]);

  const multiplyNumbers = () => {
    const multipliedValue = num1 * num2;
    setResult(multipliedValue);
  };

  return (
    <div className="flex w-full items-center justify-center space-x-8 mt-32 ">
      <div
        className={`bg-yellow-200 w-4/12 h-96 rounded text-center shadow-2xl`}
        style={{ backgroundColor: backgroundColor }}
      >
        {`${result}: نتیجه `}
      </div>
      <div className="bg-yellow-200 w-2/12 h-96 rounded shadow-2xl">
        <div className="w-48 mt-10">
          <div className="">
            <h1 className="text-right pb-4">عدد اول</h1>
            <input
              className="ml-20 rounded shadow-xl items-center"
              type="number"
              name="num1"
              value={num1}
              onChange={(e) => setNum1(parseInt(e.target.value))}
            />
          </div>
          <div className="pt-4">
            <h1 className="text-right pb-4">عدد دوم</h1>
            <input
              className="ml-20 rounded shadow-xl"
              type="number"
              name="num2"
              value={num2}
              onChange={(e) => setNum2(parseInt(e.target.value))}
            />
          </div>
          <br></br>
          <button
            onClick={multiplyNumbers}
            className="bg-orange-400 ml-32 hover:bg-orange-600 text-white font-bold py-2 px-4 rounded shadow-xl"
          >
            محاسبه
          </button>
        </div>
      </div>
    </div>
  );
}

export default Body;